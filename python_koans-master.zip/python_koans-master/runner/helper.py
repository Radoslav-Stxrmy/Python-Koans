#!/usr/bin/env python
# -*- coding: utf-8 -*-

def cls_name(obj):
    return obj.__class__.__name__